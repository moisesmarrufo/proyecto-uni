/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_uni.Control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author kk
 */
public class LoginControl {
public String usuario , contraseña;

PreparedStatement pr;
CallableStatement cs;

public LoginControl(String usuario, String contraseña){
    
try(Connection con = Conexion.getConnection()){
 pr =   con.prepareStatement(" ");
    
}catch(Exception e ){
    
}
    
    
    
}


}
