/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_uni.Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Guillermo
 */
public class Conexion {
   
    private static final String URL_SERVER = "jdbc:mysql://localhost:3306/";
    private static final String DB_NAME = "base_1";
    private static final String USER = "root";
    private static final String PASSWORD = ""; 
    
    // El bloque 'static' se ejecuta automáticamente una sola vez cuando se carga la clase
    static {
        try {
            // 1. Cargar el Driver (El "traductor")
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Conectar al servidor raíz para asegurar que la DB existe
            try (Connection tempCon = DriverManager.getConnection(URL_SERVER, USER, PASSWORD);
                 Statement st = tempCon.createStatement()) {
                
                st.execute("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
                System.out.println("Base de datos verificada/creada con éxito.");
                 
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Error: ¡No se encontró el Driver de MySQL! Agrega el JAR al proyecto."  + e);
        } catch (SQLException e) {
            System.err.println("Error crítico al inicializar la base de datos: " + e.getMessage());
        }
    }
 
    // Ahora simplemente devuelve la conexión
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL_SERVER + DB_NAME, USER, PASSWORD);
        } catch (SQLException e) {
            System.err.println("Error al conectar con la DB: " + e.getMessage());
            return null;
        }
    }
}