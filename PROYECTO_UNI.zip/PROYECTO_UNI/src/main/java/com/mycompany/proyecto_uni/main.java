/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_uni;

import com.mycompany.proyecto_uni.Control.PROYECTO_UNI;
import com.mycompany.proyecto_uni.Visual.registro_user;
import java.sql.SQLException;
import model.persona;

/**
 *
 * @author moises
 */
public class main{
   public static void main(String[] args) {
 
registro_user jFrame_Registro = new registro_user() ;
persona Persona_Prueba= new persona();
PROYECTO_UNI Prueba= new PROYECTO_UNI(jFrame_Registro, Persona_Prueba);

jFrame_Registro.setVisible(true);


    } 
}
