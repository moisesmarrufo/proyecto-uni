/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_uni.Control;

import com.mycompany.proyecto_uni.Visual.registro_user;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.persona;

/**
 *
 * @author kk
 */
public class PROYECTO_UNI  implements ActionListener{

registro_user jFrame_Registro;
persona Persona_Prueba;



    public PROYECTO_UNI(registro_user jFrame_Registro, persona Persona_Prueba) {
        this.jFrame_Registro = jFrame_Registro;
        this.Persona_Prueba = Persona_Prueba;
        this.jFrame_Registro.jButton1.addActionListener(this);

    }

@Override
 public void actionPerformed(ActionEvent e) {
 Persona_Prueba.setPrimer_Nombre(jFrame_Registro.jTextField1.getText());
 Persona_Prueba.setPrimer_Apellido(jFrame_Registro.jTextField2.getText());
 Persona_Prueba.setCI(jFrame_Registro.jTextField3.getText());
 Persona_Prueba.setEdad(Integer.parseInt(jFrame_Registro.jTextField7.getText()));
 if(e.getSource() == jFrame_Registro.jButton1){
     Persona_Prueba.agregarTablaPersona();
 Persona_Prueba.agregarUnaPersona();
 }else{
     System.out.println("Error");
 }
 
 }


       
   
/*     public  static  void Registro(String codigo, String nombre, String apellido,  String CI, int edad ) throws SQLException{
    String sql = "INSERT INTO USER (codigo, nombre, apellido, CI, edad) VALUES (?, ?, ?, ?, ?)"; 
    
    // 2. Usamos try-with-resources para Connection y PreparedStatement
    try (Connection con = Conexion.getConnection();
         PreparedStatement pstmt = con.prepareStatement(sql)) {
        
        // 3. Asignamos las variables a cada signo de interrogación (el índice empieza en 1)
        pstmt.setString(1, codigo);
        pstmt.setString(2, nombre);
        pstmt.setString(3, apellido);
        pstmt.setString(4, CI);
        pstmt.setInt(5, edad);

        // 4. Usamos executeUpdate() para operaciones INSERT, UPDATE o DELETE
        int filasAfectadas = pstmt.executeUpdate();
        
        if (filasAfectadas > 0) {
            System.out.println("Se logró registrar con éxito.");
        }
        
    } catch (SQLException e) {
        System.out.println("Error al intentar registrar: " + e.getMessage());
    }
}
  
        
     
        
  */  


   
}
