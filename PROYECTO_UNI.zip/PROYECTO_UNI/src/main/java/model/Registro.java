/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import com.mycompany.proyecto_uni.Control.Conexion;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author kk
 */
public class Registro {
  
  private Conexion cona; 
    public static void agregarTabla() throws SQLException {

        String Query ="create table if not exists USER( "
                + "codigo varchar(100)not null, "
                + " nombre varchar(100)not null, "
                + "apellido int not null,"
                + " CI varchar(100)not null, "
                + " varchar(100)not null );";  
         try (Connection Con = Conexion.getConnection();
                 Statement st = Con.createStatement()) {
            
                st.execute(Query);  
               
                System.out.println("TABLAS INSERTADAS");
                 
            } catch (Exception e) {
            System.err.println(e + "Error al inicializar: ");
        }
}
  
}
