/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import com.mycompany.proyecto_uni.Control.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

/**
 *
 * @author kk
 */
public class persona {
  private String Primer_Nombre ;
  private String Primer_Apellido ;
  private String CI ;
  private int edad;
 

  
 
               
                
                     
    
       
    public persona(){}

    public persona(String Primer_Nombre, String Primer_Apellido, String CI, int edad) {
        this.Primer_Nombre = Primer_Nombre;
        this.Primer_Apellido = Primer_Apellido;
        this.CI = CI;
        this.edad = edad;
    }

    public String getPrimer_Nombre() {
        return Primer_Nombre;
    }

    public void setPrimer_Nombre(String Primer_Nombre) {
        this.Primer_Nombre = Primer_Nombre;
    }

    public String getPrimer_Apellido() {
        return Primer_Apellido;
    }

    public void setPrimer_Apellido(String Primer_Apellido) {
        this.Primer_Apellido = Primer_Apellido;
    }

    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

  
    
    public void agregarTablaPersona(){
     String Query ="create table if not exists Persona( "
                + "PersonaId int not null AUTO_INCREMENT, "
                + "Primer_Nombre varchar(100),"
                + "Primer_Apellido varchar(100),"
                + "CI varchar(100), "
                + "edad int, "
             + "primary key (PersonaId));";  
         try (Connection Con = Conexion.getConnection();
                 Statement st = Con.createStatement()) {
            
                st.execute(Query);  
              
                System.out.println("TABLAS INSERTADAS");
                 
            } catch (Exception e) {
            System.err.println(e + "Error al inicializar: ");
        }

    
    }
public  void agregarUnaPersona(){
    
    String query = "INSERT INTO Persona (Primer_Nombre, Primer_Apellido,  CI, edad) VALUES (?,?,?,?);";
      try (Connection Con = Conexion.getConnection();
                 PreparedStatement Pst = Con.prepareStatement(query)) {
                 Pst.setString(1, this.Primer_Nombre);
                 Pst.setString(2, this.Primer_Apellido);
                 Pst.setString(3, this.CI);
                 Pst.setInt(4, this.edad);
            
          
                int RowInserted = Pst.executeUpdate();
                System.out.println("Registro exitoso"+ RowInserted);
                 
      } catch (Exception e) {
            System.err.println(e + "Error al inicializar: ");
        }

            
}
   public static void droptable(){
     String sql = "drop table if exists USER"; 
       try (Connection con = Conexion.getConnection()){
             Statement st = con.createStatement();

       st.execute(sql);
           System.out.println("se logro borrar con exito");
           
       }catch(Exception e ){
           System.out.println("error " + e);
       }
       
}
}
