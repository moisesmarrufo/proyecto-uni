
package model;
        
import com.mycompany.proyecto_uni.Control.Conexion;

import java.sql.DriverManager;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class USER extends persona{
protected String nombre_user;
 protected int id;
 protected String contraseña;
 
 public USER(){}

    public USER(String nombre_user, int id, String contraseña) {
        this.nombre_user = nombre_user;
        this.id = id;
        this.contraseña = contraseña;
    }

    public USER(String nombre_user, int id, String contraseña, String Primer_Nombre, String Primer_Apellido, String CI, int edad) {
        super(Primer_Nombre, Primer_Apellido, CI, edad);
        this.nombre_user = nombre_user;
        this.id = id;
        this.contraseña = contraseña;
    }
 
 

    public String getContraseña() {
        return contraseña;
    }

    public String getNombre_user() {
        return nombre_user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre_user(String nombre_user) {
        this.nombre_user = nombre_user;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }



  


   
    
  
   




       public static void agregarTabla() throws SQLException {

       
}
}

        
   
          

